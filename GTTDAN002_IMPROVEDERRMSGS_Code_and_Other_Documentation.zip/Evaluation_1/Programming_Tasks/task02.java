import java.util.Scanner;

public class task02 
{
    public static void obtainData()
    {
        MinorMember mm = new MinorMember();
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the member's first name: ");
        mm.setMemberFirstName(scanner.nextLine());

        System.out.println("Enter the member's last name: ");
        mm.setMemberLastName(scanner.nextLine());

        System.out.println("Enter the member's age: ");
        mm.setMemberAge(scanner.nextInt());

        scanner.nextLine();

        System.out.println("Enter the member's join date: ");
        mm.setMemberJoinDate(scanner.nextLine());

        System.out.println(mm.toString());

        scanner.close();
    }
    
    public static void main(String args[])
    {
        obtainData();
    }
}