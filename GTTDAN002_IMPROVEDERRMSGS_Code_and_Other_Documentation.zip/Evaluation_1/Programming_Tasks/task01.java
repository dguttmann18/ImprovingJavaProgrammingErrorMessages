import java.util.Scanner;

public class task01
{
    public static void meetingPlanner()
    {
        int numberOfParticipants;
        String namesOfPartipants[];
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of participants: ");
        numberOfParticipants = scanner.nextInt();

        scanner.nextLine();

        namesOfPartipants = new String[numberOfParticipants];

        for (int i=1; i<=numberOfParticipants; ++i)
        {
            System.out.println("Enter the name of participant " + i + ": ");
            namesOfPartipants[i] = scanner.nextLine();
        }

        scanner.close();
    }

    public static void main (String args[])
    {
        meetingPlanner();
    }
}