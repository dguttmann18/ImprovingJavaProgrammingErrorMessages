import java.util.Scanner;


public class task03
{
    public static void getMemberDetails()
    {
        String memberName;
        String memberIDNumber;
        int memberAge;

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the member's name: ");
        memberAge = scanner.nextInt();

        scanner.nextLine();

        System.out.println("Enter the member's ID Number: ");
        memberIDNumber = scanner.nextLine();

        System.out.println("Enter the member's age: ");
        memberName = scanner.nextLine();

        scanner.close();

        String s = "Member Details\n===================================" + 
            "\nName:\t\t" + memberName + "\nID Number:\t" + memberIDNumber + "\nAge:\t\t" + memberAge;
        
        System.out.println(s);


    }
    public static void main (String args[])
    {
        getMemberDetails();
    }
}