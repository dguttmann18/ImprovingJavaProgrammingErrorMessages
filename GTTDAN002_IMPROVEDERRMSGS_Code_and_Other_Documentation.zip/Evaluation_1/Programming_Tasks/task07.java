import java.util.Scanner;

public class task07 
{     
    public static void obtainData()
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of members: ");
        int numMembers = scanner.nextInt();

        String members[] = new String[numMembers];

        for (int i=0; i<numMembers; ++i)
        {
            System.out.println("Enter the name of member #" + (i+1) + ": ");
            members[i] = scanner.next();
        }

        scanner.close();

        for (int i=0; i<numMembers; ++i)
        {
            System.out.println("Member #" + (i+1) + ": \t\t" + members[i]);
        }
        
    }
    
    public static void main(String args[])
    {
        obtainData();
    }
}