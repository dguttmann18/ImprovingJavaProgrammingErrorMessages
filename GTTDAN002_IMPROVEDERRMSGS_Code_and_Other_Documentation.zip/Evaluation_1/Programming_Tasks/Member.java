import java.util.Calendar;

public class Member
{
    private String memberFirstName;
    private String memberLastName;
    private int memberAge;
    private String memberJoinDate;

    public Member()
    {
        memberFirstName = "";
        memberLastName = "";
        memberAge = 0;
        memberJoinDate = Calendar.getInstance().getTime().toString();
    }

    public Member(String fn, String ln, int a, String d)
    {
        memberFirstName = fn;
        memberLastName = ln;
        memberAge = a;
        memberJoinDate = d;
    }

    public String getMemberFirstName()
    {
        return memberFirstName;
    }

    public String getMemberLastName()
    {
        return memberLastName;
    }

    public int getMemberAge()
    {
        return memberAge;
    }

    public String getMemberJoinDate()
    {
        return memberJoinDate;
    }

    public void setMemberFirstName(String fn)
    {
        memberFirstName = fn;
    }

    public void setMemberLastName(String ln)
    {
        memberLastName = ln;
    }

    public void setMemberAge(int a)
    {
        memberAge = a;
    }

    public void setMemberJoinDate(String d)
    {
        memberJoinDate = d;
    }

    public String toString()
    {
        String s = "Member Details:\n======================================" +
            "\nFirst Name: \t\t" + memberFirstName +
            "\nLast Name: \t\t" + memberLastName +
            "\nAge: \t\t\t" + memberAge +
            "\nJoin Date: \t\t" + memberJoinDate;
        
        return s;
    }
}