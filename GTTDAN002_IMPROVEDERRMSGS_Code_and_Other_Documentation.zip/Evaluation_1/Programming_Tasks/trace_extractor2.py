import re


# Function to extract the name of the exception class and error message from a Java stack trace
def extract_exception_info(stack_trace):
    data = []

    if stack_trace.find(":") > 0:
        pattern = r"Exception in thread (\S+) (.*?):\s*(.*)"
        match = re.match(pattern, stack_trace)

        if match:
            exception_class = match.group(2).strip()
            error_message = match.group(3).strip()

            data.append(exception_class)
            data.append(error_message)

            return data
    else:
        s = stack_trace.split(" ")
        data.append(s[-1])

        return data


stack_trace = ""

# Obtain Java stack trace from program input
while not stack_trace.startswith("Exception in thread"):
    stack_trace = input()

# Pass data to extract_exception_info() function
data = extract_exception_info(stack_trace)

# Output name of exception class and error message
if len(data) > 0:
    print(data[0])

if len(data) == 2:
    print(data[1])
else:
    print("")
