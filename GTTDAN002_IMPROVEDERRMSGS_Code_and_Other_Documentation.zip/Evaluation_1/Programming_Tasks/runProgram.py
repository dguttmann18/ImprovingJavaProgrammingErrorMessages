import os, sys, time


# Function to obtain error message type from text file "format.txt"
def check_runType_and_language():
    f = open("format.txt")
    lines = f.readlines()
    f.close()

    if len(lines) == 1:
        return lines[0], ""
    elif len(lines) == 2:
        return lines[0], lines[1]


# Function to determine whether the given Java stack trace contains an exception
def containsException():
    f = open("in.txt")
    lines = f.readlines()
    f.close()

    for l in lines:
        if l.startswith("Exception"):
            return True

    return False


# Function to obtain exception data from stack trace
def extractPreException():
    f = open("in.txt")

    lines = f.readlines()
    f.close()
    s = ""

    for l in lines:
        l = l.strip()

        if l.startswith("Exception"):
            return s
        else:
            s += l + "\n"


# Function to replace standard output with improved output
def amendOutput():
    s = extractPreException()

    f = open("testoutput.out")
    lines = f.readlines()
    f.close()

    lines[0] = s + "\n" + lines[0]

    s = ""

    for l in lines:
        s += l + "\n"

    f = open("testoutput.out", "w")
    f.write(s)
    f.close()


def main():
    # Obtain error message type (standard, improved English, or improved Afrikaans)
    runType, lang = check_runType_and_language()

    runType = runType.strip()
    testIn = sys.argv[2]

    # If "standard error messages" are selected, compile and run the given Java program and with input from given text file
    # and redirect output to "testoutput.out"
    if runType == "S":
        os.system("rm *.class")
        os.system("javac *.java")
        os.system("java " + sys.argv[1] + " < " + testIn + " > testoutput.out 2>&1")

    # If "enhanced error messages" are selected, compile and run the given Java program and with input from given text file
    # and redirect output to "in.txt" and then run "trace_extractor2.py" and "template_extractor.py"
    elif runType == "E":
        os.system("rm *.class")
        os.system("javac *.java")

        prog = sys.argv[1]

        os.system("java " + prog + " > in.txt < " + testIn + " 2>&1")

        if containsException():
            os.system("python3 trace_extractor2.py < in.txt > out1.txt 2>&1")
            os.system(
                'python3 template_extractor.py "'
                + lang
                + '" < out1.txt > testoutput.out 2>&1'
            )
            amendOutput()
        else:
            os.system("cp in.txt testoutput.out")


main()
