public class Mem {
    private String memberFirstName;
    private String memberLastName;
    private int memberAge;
    private Mem partner;

    public static void main (String args[])
    {
        Mem m = new Mem("Harry", "Potter", 43);
        System.out.println(m.toString());
    }

    public Mem(String fn, String ln, int a) {
        memberFirstName = fn;
        memberLastName = ln;
        memberAge = a;
    }

    public String toString() {
        
        return "Member Details:\n======================================" +
                "\nFirst Name: \t\t" + memberFirstName +
                "\nLast Name: \t\t" + memberLastName +
                "\nAge: \t\t\t" + memberAge +
                "\nPartner Details:\n" + partner.toString();
    }
}