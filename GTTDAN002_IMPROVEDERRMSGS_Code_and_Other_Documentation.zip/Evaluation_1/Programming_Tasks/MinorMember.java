public class MinorMember extends Member
{
    private Member mainMember;

    public MinorMember()
    {
        super();
    } 

    public MinorMember(Member m)
    {
        super();
        mainMember = m;
    }

    public MinorMember(String fn, String ln, int a, String d, Member m)
    {
        super(fn, ln, a, d);
        mainMember = m;
    }

    public void setMainMember(Member m)
    {
        mainMember = m;
    }

    public Member getMainMember()
    {
        return mainMember;
    }

    public String toString()
    {
        return super.toString() + "\nMainMember:\n====\n" + mainMember.toString();
    }
}