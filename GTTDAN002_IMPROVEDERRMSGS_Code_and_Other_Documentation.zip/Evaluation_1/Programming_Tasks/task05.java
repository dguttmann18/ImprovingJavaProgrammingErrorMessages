import java.util.Scanner;

public class task05 
{
    public static void doCalculation(int i, int j)
    {
        System.out.println(i/j);
    }
    
    
    public static void obtainData()
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a number: ");
        int num_1 = scanner.nextInt();

        System.out.println("Enter another number: ");
        int num_2 = scanner.nextInt();


        scanner.close();

        doCalculation(num_1, num_2);
    }
    
    public static void main(String args[])
    {
        obtainData();
    }
}