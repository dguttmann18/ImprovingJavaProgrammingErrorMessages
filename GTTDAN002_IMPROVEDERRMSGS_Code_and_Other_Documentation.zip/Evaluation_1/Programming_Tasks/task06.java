import java.util.Scanner;

public class task06 
{
    public static void obtainData()
    {
        Member m = new Member();
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the member's first name: ");
        m.setMemberFirstName(scanner.nextLine());

        System.out.println("Enter the member's last name: ");
        m.setMemberLastName(scanner.nextLine());

        System.out.println("Enter the member's age: ");
        m.setMemberAge(scanner.nextInt());

        scanner.nextLine();

        System.out.println("Enter the member's join date: ");
        m.setMemberJoinDate(scanner.nextLine());

        System.out.println("Does this member want to become a minor member (Y or N): ");
        String response = scanner.nextLine();

        if (response.equals("Y"))
        {
            MinorMember mm = (MinorMember) m;
            System.out.println(mm.toString());
        }
        else
        {
            System.out.println(m.toString());
        }

        scanner.close();
    }
    
    public static void main(String args[])
    {
        obtainData();
    }
}