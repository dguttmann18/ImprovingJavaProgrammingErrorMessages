import java.util.Scanner;

public class task04
{
    public static void generateCode(String fName, String lName)
    {
        String s;

        s = fName.substring(0, 2) + lName.substring(6, 7);

        System.out.println(s);
    }

    public static void obtainDetails()
    {
        String firstName;
        String lastName;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the member's first name: ");
        firstName = scanner.nextLine();

        System.out.println("Enter the member's last name: ");
        lastName = scanner.nextLine();

        scanner.close();

        generateCode(firstName, lastName);
    }

    public static void main (String args[])
    {
        obtainDetails();
    }
}