import re
import sys

# Dictionary of exception classes and their corresponding message templates
templates = {
    "java.lang.ArrayIndexOutOfBoundsException": [
        r":\s*(-?\d+)",
        r"Index (-?\d+) out of bounds for length (-?\d+)",
    ],
    "java.lang.NullPointerException": [r"(.+?) must not be null", r"(.+?) is null"],
    "java.util.InputMismatchException": [
        r"For input string: (\S+)",
    ],
    "java.lang.StringIndexOutOfBoundsException": [
        r"String index out of range: (-?\d+)",
        r"begin (-?\d+), end (-?\d+), length (-?\d+)",
    ],
    "java.lang.NumberFormatException": [
        r"For input string: (\S+)",
    ],
    "java.lang.IndexOutOfBoundsException": [
        r"No group (-?\d+)",
        r"index = (-?\d+) size = (-?\d+)",
        r"No such element as (-?\d+)",
        r"(-?\d+)",
    ],
    "java.io.FileNotFoundException": [
        r"(\S+) (The system cannot find the file specified)",
    ],
    "java.util.NoSuchElementException": [
        r"FileResource: no file chosen for reading",
        r"FileResource: cannot access (.+?)",
        r"URLResource: cannot access (.+?)",
        r"ImageResource: unable to find (.+?)",
    ],
    "java.sql.SQLException": [r"FileResource: cannot access"],
    "java.lang.ClassCastException": [
        r"class (.+?) cannot be cast to class \s*",
    ],
    "java.io.IOException": [
        r"File not found: (\S+)",
    ],
    "java.lang.NegativeArraySizeException": [
        r"(-\d+)",
    ],
    "java.lang.UnsupportedOperationException": [
        r"Unsupported character (\S+) at index (\d+)",
    ],
    "java.lang.Exception": [
        r"Tallet (-?\d+) har ikke en invers",
    ],
    "java.sql.SQLException": [
        r"(.+?) Could not find file (.+?)",
        r"(.+?) Data Source name not found and no default drive specified",
        r"(.+?) The Microsoft Jet database engine cannot find the input table or query (\S+). Make sure it exists and that its name is spelled correctly.",
        r"No suitable driver found for (.+?)",
        r"path to (.+?) does not exist",
    ],
    "java.time.format.DateTimeParseException": [
        r"Text (\S+) could not be parsed at index (-?\d+)",
    ],
    "java.lang.IncompatibleClassChangeError": [
        r"Expected static method (.+?)",
        r"Expected non-static method (.+?)",
    ],
    "java.net.MalformedURLException": [
        r"unknown protocol: (.+?)",
        r"no protocol: (.+?)",
        r"Unsupported protocol: (.+?)",
    ],
    "java.time.DateTimeException": [
        r"Unable to extract value: (.+?)",
        r"Invalid value for MonthOfYear (valid values 1-12): (-?\d+)",
        r"Inavalid value for DayOfMonth (valid values 1-28/31) (-?\d+)",
        r"Invalid value for SecondOfMinute (valid values 0-59): (-?\d+)",
        r"Invalid dayOfYear: (-?\d+)",
        r"Invalid value for HourOfDay (valid values 0-23): (-?\d+)",
        r"Invalid date \'February 29\' as (\S+) is not a leap year",
    ],
    "java.lang.ClassNotFoundException": [
        r"(\S+)",
        r"class (.+?) cannot be cast to class (.+?)",
    ],
    "java.lang.ClassFormatError": [
        r"Unknown constant tag (-?\d+) in class file (.+?)",
        r"Incompatable magic value (-?\d+) in class file (.+?)",
        r"Extra bytes at end of class file (.+?)",
        r"Absent Code attribute in method that is not native or abstract in class file (.+?)",
    ],
    "java.io.NotSerializableException": [
        r"(\S+)",
    ],
    "java.text.ParseException": [
        r"Unparseable date: (\S+)",
    ],
    "java.awt.image.RasterFormatException": [
        r"((.+?)) is outside of Raster",
        r"Transformed width ((-?\d+)) is less than or equal to (-?\d+).",
        r"Data array too small (should be > (-?\d+))",
    ],
    "java.lang.ArithmeticException": [r".*"],
}


# Function that returns an improved error message given an exception class, data, and an improved error message type
def getImprovedTemplate(exceptionClass, data, lang):
    exceptionClass = exceptionClass.strip()

    # Improved error messages in English
    if lang == "E":
        if exceptionClass == "java.lang.ArrayIndexOutOfBoundsException":
            return (
                "Array elements begin at 0. If an array has a length of "
                + str(data[0])
                + ", it only has elements ranging from 0 to "
                + str(int(data[0]) - 1)
                + "."
            )
        elif exceptionClass == "java.lang.NullPointerException":
            return "You are attempting to use data from a variable that does not contain any data."
        elif exceptionClass == "java.util.InputMismatchException":
            return "The input data obtained on the last line is in the incorrect format. Perhaps, a number was expected, but text was provided."
        elif exceptionClass == "java.lang.StringIndexOutOfBoundsException":
            return (
                "You are attempting to extract characters between positions "
                + str(data[0])
                + " and "
                + str(data[1])
                + " from text that only has "
                + str(data[2])
                + " character(s)."
            )
        elif exceptionClass == "java.lang.ArithmeticException":
            return (
                'The mathematical operation "'
                + str(data)
                + '" resulted in a mathematical error.'
            )
        elif exceptionClass == "java.lang.StackOverflowError":
            return "The program has caused the computer to run out of memory space. This could be due to a method or a loop running too many times."
        elif exceptionClass == "java.lang.ClassCastException":
            return (
                "It is not possible to covert a "
                + data[0]
                + " into a "
                + data[1]
                + ", as they are different."
            )
        elif exceptionClass == "java.lang.NegativeArraySizeException":
            return "You are attempting create an array with a negative number of elements. An array may not have a length less than 0."

    # Improved error messages in Afrikaans
    elif lang == "A":
        if exceptionClass == "java.lang.ArrayIndexOutOfBoundsException":
            return (
                "Skikking elemente begin by nul. As 'n skikking 'n lengte van "
                + str(data[0])
                + " het, het dit net elemente wat wissel van 0 tot "
                + str(int(data[0]) - 1)
                + "."
            )
        elif exceptionClass == "java.lang.NullPointerException":
            return "Jy probeer om data van 'n veranderlike te gebruik wat geen data behels nie."
        elif exceptionClass == "java.util.InputMismatchException":
            return "Die invoer data verkry op die laaste lyn is in die inkorrekte formaat. Daar was dalk 'n nommer verwag, maar teks is verskaf."
        elif exceptionClass == "java.lang.StringIndexOutOfBoundsException":
            return (
                "Jy probeer om karakters te onttrek tussen posisies "
                + str(data[0])
                + " en "
                + str(data[1])
                + " vanaf teks wat net uit "
                + str(data[2])
                + " karakter(s) bestaan."
            )
        elif exceptionClass == "java.lang.ArithmeticException":
            return (
                'Die wiskundige bewerking "'
                + str(data)
                + "\" het gelei tot 'n wiskundige fout."
            )
        elif exceptionClass == "java.lang.StackOverflowError":
            return "The program has caused the computer to run out of memory space. This could be due to a method or a loop running too many times."
        elif exceptionClass == "java.lang.ClassCastException":
            return (
                "Dit is nie moontlik om 'n "
                + data[0]
                + " na 'n "
                + data[1]
                + " te omskep nie, omdat hulle verskillend is."
            )
        elif exceptionClass == "java.lang.NegativeArraySizeException":
            return "Jy probeer om 'n skikking te skep met 'n negatiewe hoeveelheid van elemente. 'n Skikking mag nie 'n lengte minder as nul hê nie."


# Function to extract the data from the error message using the appropriate template
def extract_data(exception, message):
    if exception == "java.lang.ArithmeticException":
        return message
    elif exception == "java.lang.ClassCastException":
        return re.findall(r"class (\w+)", message)
    elif exception in templates:
        template_list = templates[exception]
        for template in template_list:
            match = re.search(template, message)
            if match:
                return match.groups()
    return None


lang = sys.argv[1]

exception = input()
message = input()
data = extract_data(exception, message)

# Output improved error message
print(getImprovedTemplate(exception, data, lang))
